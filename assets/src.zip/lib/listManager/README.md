# listManager.js
###实现功能
listManager.js实现以下功能，且调用方便快捷。但需注意的是该插件是基于table进行开的

- 列宽度调整
- 列位置更换
- 列表头提醒
- 列表项排序功能
- 配置列是否可视功能
- 支持ajax分页
- 表头吸顶效果
- 主JS压缩后只有16kb

###演示及文档
- [功能演示](http://www.lovejavascript.com/zone/listManager/demo.html)

- [原站地址及使用说明](http://www.lovejavascript.com/#!zone/listManager)
